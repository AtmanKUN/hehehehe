function openBox() {
    document.getElementById('pokeball').style.display = 'none';
    document.getElementById('ring').classList.remove('hidden');
}

function showLoveMessage() {
    document.getElementById('ring').classList.add('hidden');
    document.getElementById('loveMessage').classList.remove('hidden');
}
